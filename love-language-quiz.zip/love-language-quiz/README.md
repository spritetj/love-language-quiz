# HAAB Love Language Quiz 💕

แบบทดสอบ 5 Love Languages สำหรับแคมเปญ Valentine ของ HAAB

## วิธี Host บน GitHub Pages

### 1. สร้าง Repository ใหม่บน GitHub
- ไปที่ https://github.com/new
- ตั้งชื่อ repository เช่น `love-language-quiz`
- เลือก **Public**
- คลิก **Create repository**

### 2. Upload ไฟล์
Upload ไฟล์ทั้งหมดใน folder นี้:
```
love-language-quiz/
├── index.html
├── images/
│   ├── A.png (Words of Affirmation)
│   ├── B.png (Acts of Service)
│   ├── C.png (Receiving Gifts)
│   ├── D.png (Quality Time)
│   └── E.png (Physical Touch)
└── README.md
```

### 3. เปิด GitHub Pages
1. ไปที่ **Settings** > **Pages**
2. Source: เลือก **Deploy from a branch**
3. Branch: เลือก **main** และ **/ (root)**
4. คลิก **Save**

### 4. รอ 1-2 นาที
- URL จะเป็น: `https://[username].github.io/love-language-quiz/`

## Features
- ✅ 7 คำถาม Love Language
- ✅ Animation สวยงาม
- ✅ Responsive สำหรับมือถือ
- ✅ ผลลัพธ์ 5 แบบตาม Love Language
- ✅ ปุ่มบันทึกรูปและ Share IG Story
- ✅ Confetti effect เมื่อได้ผลลัพธ์
- ✅ HAAB Branding

## Love Languages
| Choice | Love Language |
|--------|---------------|
| A | Words of Affirmation (คำพูดยืนยันรัก) |
| B | Acts of Service (การกระทำ) |
| C | Receiving Gifts (ของขวัญ) |
| D | Quality Time (เวลาคุณภาพ) |
| E | Physical Touch (สัมผัสทางกาย) |

## การใช้งานบน IG
1. ใส่ลิงก์ Quiz ไว้ใน IG Bio
2. โพสต์ Story ชวนคนมาทำ Quiz
3. เมื่อทำเสร็จ กดบันทึกรูป แล้ว Share ต่อได้เลย!

---
Made with 💕 for HAAB Valentine Campaign
